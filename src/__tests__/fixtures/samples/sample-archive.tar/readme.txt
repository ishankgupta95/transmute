Transmute archive fixture.
